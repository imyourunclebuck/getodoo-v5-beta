import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createOpenAI } from '@ai-sdk/openai';
import { createTool } from '@mastra/core/tools';
import { GoogleGenAI } from '@google/genai';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  const pathWithoutSlash = path.replace(/^\/+/, "");
  const pathWithoutApi = pathWithoutSlash.startsWith("api/") ? pathWithoutSlash.substring(4) : pathWithoutSlash;
  const connectorName = pathWithoutApi.split("/")[0];
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${connectorName}`,
        name: path
      },
      {
        // Match the event pattern created by createWebhook: event/api.webhooks.{connector-name}.action
        event: `event/api.webhooks.${connectorName}.action`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const headers = { ...event.data.headers ?? {} };
          if (event.data.runId) {
            headers["x-mastra-run-id"] = event.data.runId;
          }
          const response = await fetch(`http://localhost:5000${path}`, {
            method: event.data.method,
            headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "Trying to initialize Telegram triggers without TELEGRAM_BOT_TOKEN. Can you confirm that the Telegram integration is configured correctly?"
  );
}
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] payload", payload);
          const message = payload.message;
          const voiceFileId = message?.voice?.file_id;
          await handler(mastra, {
            type: triggerType,
            params: {
              userName: message?.from?.username || message?.from?.first_name || "Unknown",
              message: message?.text || "",
              chatId: message?.chat?.id,
              voiceFileId
            },
            payload
          });
          return c.text("OK", 200);
        } catch (error) {
          logger?.error("Error handling Telegram webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

function getOdooConfig() {
  return {
    url: process.env.ODOO_URL || "",
    db: process.env.ODOO_DB || "",
    username: process.env.ODOO_LOGIN || "",
    password: process.env.ODOO_PASSWORD || ""
  };
}
async function odooRpc(endpoint, service, method, args) {
  const config = getOdooConfig();
  const response = await fetch(`${config.url}${endpoint}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: Date.now(),
      method: "call",
      params: {
        service,
        method,
        args
      }
    })
  });
  const data = await response.json();
  if (data.error) {
    throw new Error(
      `Odoo Error: ${data.error.message} - ${data.error.data?.message || ""}`
    );
  }
  return data.result;
}
async function authenticate() {
  const config = getOdooConfig();
  const uid = await odooRpc("/jsonrpc", "common", "authenticate", [
    config.db,
    config.username,
    config.password,
    {}
  ]);
  if (!uid) {
    throw new Error("Odoo authentication failed. Check credentials.");
  }
  return uid;
}
async function executeKw(model, method, args, kwargs = {}) {
  const config = getOdooConfig();
  const uid = await authenticate();
  return await odooRpc("/jsonrpc", "object", "execute_kw", [
    config.db,
    uid,
    config.password,
    model,
    method,
    args,
    kwargs
  ]);
}
const odooSearchTool = createTool({
  id: "odoo-search",
  description: "Search for records in Odoo database. Use this to find existing records like customers, products, sales orders, invoices, etc. Returns a list of matching records with their data.",
  inputSchema: z.object({
    model: z.string().describe(
      "The Odoo model to search (e.g., 'res.partner' for customers, 'product.product' for products, 'sale.order' for sales orders, 'account.move' for invoices)"
    ),
    domain: z.string().optional().default("[]").describe(
      `Search filter domain as a JSON string (e.g., '[["name", "ilike", "John"], ["is_company", "=", true]]'). Use empty array '[]' for no filter.`
    ),
    fields: z.array(z.string()).optional().default(["id", "name", "display_name"]).describe("List of fields to retrieve (e.g., ['name', 'email', 'phone'])"),
    limit: z.number().optional().default(10).describe("Maximum number of records to return"),
    offset: z.number().optional().default(0).describe("Number of records to skip (for pagination)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    records: z.array(z.record(z.any())),
    count: z.number(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const config = getOdooConfig();
    logger?.info("\u{1F50D} [odooSearchTool] Searching Odoo records:", {
      model: context.model,
      domain: context.domain,
      odooUrl: config.url,
      odooDb: config.db,
      odooUsername: config.username ? "***set***" : "***not set***"
    });
    try {
      let domain = [];
      try {
        domain = JSON.parse(context.domain || "[]");
      } catch {
        logger?.warn("\u26A0\uFE0F [odooSearchTool] Failed to parse domain, using empty array");
        domain = [];
      }
      const records = await executeKw(
        context.model,
        "search_read",
        [domain],
        {
          fields: context.fields,
          limit: context.limit,
          offset: context.offset
        }
      );
      logger?.info("\u2705 [odooSearchTool] Found records:", {
        count: records.length
      });
      return {
        success: true,
        records,
        count: records.length
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooSearchTool] Error:", { error: errorMessage });
      return {
        success: false,
        records: [],
        count: 0,
        error: errorMessage
      };
    }
  }
});
const odooCreateTool = createTool({
  id: "odoo-create",
  description: "Create a new record in Odoo database. Use this to add new customers, products, sales orders, etc. Returns the ID of the newly created record.",
  inputSchema: z.object({
    model: z.string().describe(
      "The Odoo model to create a record in (e.g., 'res.partner' for customers, 'product.product' for products)"
    ),
    values: z.record(z.any()).describe(
      "Field values for the new record (e.g., {name: 'John Doe', email: 'john@example.com', phone: '+1234567890'})"
    )
  }),
  outputSchema: z.object({
    success: z.boolean(),
    recordId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u2795 [odooCreateTool] Creating Odoo record:", {
      model: context.model,
      values: context.values
    });
    try {
      const recordId = await executeKw(context.model, "create", [
        context.values
      ]);
      logger?.info("\u2705 [odooCreateTool] Created record:", { recordId });
      return {
        success: true,
        recordId
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooCreateTool] Error:", { error: errorMessage });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});
const odooUpdateTool = createTool({
  id: "odoo-update",
  description: "Update an existing record in Odoo database. Use this to modify customer details, product information, order status, etc.",
  inputSchema: z.object({
    model: z.string().describe("The Odoo model to update"),
    recordId: z.number().describe("The ID of the record to update"),
    values: z.record(z.any()).describe(
      "Field values to update (e.g., {phone: '+1234567890', city: 'New York'})"
    )
  }),
  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u270F\uFE0F [odooUpdateTool] Updating Odoo record:", {
      model: context.model,
      recordId: context.recordId,
      values: context.values
    });
    try {
      await executeKw(context.model, "write", [
        [context.recordId],
        context.values
      ]);
      logger?.info("\u2705 [odooUpdateTool] Updated record successfully");
      return {
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooUpdateTool] Error:", { error: errorMessage });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});
const odooDeleteTool = createTool({
  id: "odoo-delete",
  description: "Delete a record from Odoo database. Use with caution - this permanently removes the record. Only use when explicitly requested.",
  inputSchema: z.object({
    model: z.string().describe("The Odoo model to delete from"),
    recordId: z.number().describe("The ID of the record to delete")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F5D1}\uFE0F [odooDeleteTool] Deleting Odoo record:", {
      model: context.model,
      recordId: context.recordId
    });
    try {
      await executeKw(context.model, "unlink", [[context.recordId]]);
      logger?.info("\u2705 [odooDeleteTool] Deleted record successfully");
      return {
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooDeleteTool] Error:", { error: errorMessage });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});
const odooGetModelFieldsTool = createTool({
  id: "odoo-get-model-fields",
  description: "Get the available fields for an Odoo model. Use this to understand what data can be stored or retrieved from a model.",
  inputSchema: z.object({
    model: z.string().describe("The Odoo model to get fields for")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    fields: z.record(z.any()),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4CB} [odooGetModelFieldsTool] Getting fields for:", {
      model: context.model
    });
    try {
      const fields = await executeKw(context.model, "fields_get", [], {
        attributes: ["string", "type", "required", "help"]
      });
      logger?.info("\u2705 [odooGetModelFieldsTool] Retrieved fields");
      return {
        success: true,
        fields
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooGetModelFieldsTool] Error:", {
        error: errorMessage
      });
      return {
        success: false,
        fields: {},
        error: errorMessage
      };
    }
  }
});
const odooExecuteActionTool = createTool({
  id: "odoo-execute-action",
  description: "Execute a specific action/method on an Odoo record. Use this for actions like confirming a sale order, validating an invoice, or other workflow actions.",
  inputSchema: z.object({
    model: z.string().describe("The Odoo model"),
    method: z.string().describe(
      "The method to execute (e.g., 'action_confirm' for sales orders)"
    ),
    recordIds: z.array(z.number()).describe("The IDs of records to act upon")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    result: z.any().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u26A1 [odooExecuteActionTool] Executing action:", {
      model: context.model,
      method: context.method,
      recordIds: context.recordIds
    });
    try {
      const result = await executeKw(context.model, context.method, [
        context.recordIds
      ]);
      logger?.info("\u2705 [odooExecuteActionTool] Action executed successfully");
      return {
        success: true,
        result
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [odooExecuteActionTool] Error:", {
        error: errorMessage
      });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});

const ai = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY || "",
  httpOptions: {
    apiVersion: "",
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL || ""
  }
});
const transcribeVoiceTool = createTool({
  id: "transcribe-voice",
  description: "Transcribe a voice message from audio data. Use this to convert voice messages to text. Supports OGG, MP3, WAV, and other common audio formats.",
  inputSchema: z.object({
    audioBase64: z.string().describe("Base64 encoded audio data"),
    mimeType: z.string().optional().default("audio/ogg").describe("MIME type of the audio (e.g., audio/ogg, audio/mp3, audio/wav)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    transcription: z.string(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F3A4} [transcribeVoiceTool] Starting transcription:", {
      mimeType: context.mimeType,
      audioLength: context.audioBase64.length
    });
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: "Transcribe this audio message exactly as spoken. Return only the transcription text, nothing else."
              },
              {
                inlineData: {
                  mimeType: context.mimeType,
                  data: context.audioBase64
                }
              }
            ]
          }
        ]
      });
      const transcription = response.text || "";
      logger?.info("\u2705 [transcribeVoiceTool] Transcription complete:", {
        transcription: transcription.substring(0, 100) + "..."
      });
      return {
        success: true,
        transcription: transcription.trim()
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [transcribeVoiceTool] Error:", { error: errorMessage });
      return {
        success: false,
        transcription: "",
        error: errorMessage
      };
    }
  }
});

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const sendTelegramMessageTool = createTool({
  id: "send-telegram-message",
  description: "Send a text message to a Telegram chat. Use this to respond to users in Telegram.",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("The Telegram chat ID to send the message to"),
    message: z.string().describe("The message text to send"),
    parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).optional().describe("How to parse the message text formatting")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E4} [sendTelegramMessageTool] Sending message:", {
      chatId: context.chatId,
      messageLength: context.message.length
    });
    try {
      const response = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            chat_id: context.chatId,
            text: context.message,
            parse_mode: context.parseMode
          })
        }
      );
      const data = await response.json();
      if (!data.ok) {
        throw new Error(data.description || "Failed to send message");
      }
      logger?.info("\u2705 [sendTelegramMessageTool] Message sent:", {
        messageId: data.result.message_id
      });
      return {
        success: true,
        messageId: data.result.message_id
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [sendTelegramMessageTool] Error:", {
        error: errorMessage
      });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});
const downloadTelegramFileTool = createTool({
  id: "download-telegram-file",
  description: "Download a file from Telegram (like voice messages, images, documents). Returns the file as base64 encoded data.",
  inputSchema: z.object({
    fileId: z.string().describe("The Telegram file_id of the file to download")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    fileBase64: z.string().optional(),
    mimeType: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E5} [downloadTelegramFileTool] Downloading file:", {
      fileId: context.fileId
    });
    try {
      const fileInfoResponse = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getFile?file_id=${context.fileId}`
      );
      const fileInfo = await fileInfoResponse.json();
      if (!fileInfo.ok) {
        throw new Error(fileInfo.description || "Failed to get file info");
      }
      const filePath = fileInfo.result.file_path;
      const fileUrl = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${filePath}`;
      const fileResponse = await fetch(fileUrl);
      const arrayBuffer = await fileResponse.arrayBuffer();
      const base64 = Buffer.from(arrayBuffer).toString("base64");
      const extension = filePath.split(".").pop()?.toLowerCase() || "bin";
      let mimeType = "application/octet-stream";
      if (extension === "ogg" || extension === "oga") {
        mimeType = "audio/ogg";
      } else if (extension === "mp3") {
        mimeType = "audio/mp3";
      } else if (extension === "wav") {
        mimeType = "audio/wav";
      } else if (extension === "m4a") {
        mimeType = "audio/m4a";
      }
      logger?.info("\u2705 [downloadTelegramFileTool] File downloaded:", {
        filePath,
        mimeType,
        size: arrayBuffer.byteLength
      });
      return {
        success: true,
        fileBase64: base64,
        mimeType
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [downloadTelegramFileTool] Error:", {
        error: errorMessage
      });
      return {
        success: false,
        error: errorMessage
      };
    }
  }
});

const openai = createOpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});
const odooAgent = new Agent({
  name: "Odoo Voice Assistant",
  instructions: `
You are an intelligent Odoo database assistant that helps users manage their Odoo ERP system through voice commands and text messages.

## Your Capabilities

1. **Voice Message Processing**: 
   - When you receive a voice message (voice property in payload), first download the audio file using downloadTelegramFileTool, then transcribe it using transcribeVoiceTool
   - Process the transcribed text as a command

2. **Database Operations**:
   - Search for records (customers, products, orders, invoices, etc.)
   - Create new records
   - Update existing records
   - Delete records (only when explicitly requested and confirmed)
   - Execute workflow actions (confirm orders, validate invoices, etc.)
   - Get field information for any model

3. **Common Odoo Models**:
   - res.partner: Customers/Contacts (name, email, phone, city, country_id)
   - product.product: Products (name, list_price, qty_available)
   - product.template: Product Templates
   - sale.order: Sales Orders (partner_id, amount_total, state)
   - sale.order.line: Sales Order Lines
   - purchase.order: Purchase Orders
   - account.move: Invoices/Bills (partner_id, amount_total, state)
   - stock.picking: Inventory Transfers
   - crm.lead: CRM Leads/Opportunities
   - project.project: Projects
   - project.task: Tasks
   - hr.employee: Employees

## Guidelines

1. **Safety First**: 
   - Never delete records without explicit confirmation
   - Always verify the user's intent before making changes
   - For updates, confirm what will be changed

2. **Clear Communication**:
   - Explain what you're doing step by step
   - Show the results of searches clearly
   - Confirm successful operations

3. **Error Handling**:
   - If an operation fails, explain why and suggest alternatives
   - If you can't find records, suggest different search criteria

4. **Smart Interpretation**:
   - Understand natural language commands like "show me all customers in New York"
   - Convert to appropriate Odoo domain filters
   - Interpret "add a new customer named John" as a create operation

## Response Format

Always respond in a helpful, conversational manner. When displaying data:
- Format lists clearly
- Include relevant details (IDs, names, key fields)
- For large result sets, summarize and offer to show more

## Example Commands You Can Handle

- "Show me all customers from California"
- "Create a new customer named John Smith with email john@example.com"
- "Update the phone number for customer ID 5 to +1234567890"
- "Find all pending sales orders"
- "What products do we have in stock?"
- "Confirm sales order 123"
- "Show me the fields available for customers"
`,
  model: openai("gpt-4o"),
  tools: {
    odooSearchTool,
    odooCreateTool,
    odooUpdateTool,
    odooDeleteTool,
    odooGetModelFieldsTool,
    odooExecuteActionTool,
    transcribeVoiceTool,
    sendTelegramMessageTool,
    downloadTelegramFileTool
  },
  memory: new Memory({
    options: {
      threads: {
        generateTitle: true
      },
      lastMessages: 20
    },
    storage: sharedPostgresStorage
  })
});

const processWithOdooAgent = createStep({
  id: "process-with-odoo-agent",
  description: "Calls the Odoo AI agent to process the user message",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    userMessage: z.string().describe("The message content to send to the agent"),
    threadId: z.string().describe("Thread ID for memory context")
  }),
  outputSchema: z.object({
    agentResponse: z.string(),
    chatId: z.union([z.string(), z.number()]),
    success: z.boolean()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F680} [Step 1] Calling Odoo agent with generateLegacy");
    const response = await odooAgent.generateLegacy(
      [{ role: "user", content: inputData.userMessage }],
      {
        resourceId: String(inputData.chatId),
        threadId: inputData.threadId,
        maxSteps: 10
      }
    );
    logger?.info("\u2705 [Step 1] Agent processing complete");
    return {
      agentResponse: response.text || "I processed your request but have no response to show.",
      chatId: inputData.chatId,
      success: true
    };
  }
});
const sendTelegramResponse = createStep({
  id: "send-telegram-response",
  description: "Sends the agent's response back to the Telegram chat",
  inputSchema: z.object({
    agentResponse: z.string(),
    chatId: z.union([z.string(), z.number()]),
    success: z.boolean()
  }),
  outputSchema: z.object({
    messageSent: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E4} [Step 2] Sending response to Telegram:", {
      chatId: inputData.chatId,
      responseLength: inputData.agentResponse.length
    });
    const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
    try {
      let messageText = inputData.agentResponse;
      if (messageText.length > 4096) {
        messageText = messageText.substring(0, 4093) + "...";
      }
      const response = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            chat_id: inputData.chatId,
            text: messageText
          })
        }
      );
      const data = await response.json();
      if (!data.ok) {
        throw new Error(data.description || "Failed to send message");
      }
      logger?.info("\u2705 [Step 2] Message sent successfully:", {
        messageId: data.result.message_id
      });
      return {
        messageSent: true,
        messageId: data.result.message_id
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger?.error("\u274C [Step 2] Failed to send message:", { error: errorMessage });
      return {
        messageSent: false,
        error: errorMessage
      };
    }
  }
});
const odooTelegramWorkflow = createWorkflow({
  id: "odoo-telegram-workflow",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    userMessage: z.string().describe("The message content to send to the agent"),
    threadId: z.string().describe("Thread ID for memory context")
  }),
  outputSchema: z.object({
    messageSent: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  })
}).then(processWithOdooAgent).then(sendTelegramResponse).commit();

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    odooTelegramWorkflow
  },
  // Register your agents here
  agents: {
    odooAgent
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // ======================================================================
      // Static Web UI - Serves the public chat interface
      // ======================================================================
      {
        path: "/",
        method: "GET",
        createHandler: async () => {
          return async (c) => {
            const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Odoo AI Assistant</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .chat-container { width: 100%; max-width: 800px; background: white; border-radius: 16px; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3); display: flex; flex-direction: column; height: 90vh; max-height: 700px; }
        .chat-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 16px 16px 0 0; text-align: center; }
        .chat-header h1 { font-size: 1.5rem; margin-bottom: 5px; }
        .chat-header p { opacity: 0.9; font-size: 0.9rem; }
        .chat-messages { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 15px; }
        .message { max-width: 80%; padding: 12px 16px; border-radius: 16px; line-height: 1.5; word-wrap: break-word; }
        .message.user { align-self: flex-end; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-bottom-right-radius: 4px; }
        .message.assistant { align-self: flex-start; background: #f0f0f0; color: #333; border-bottom-left-radius: 4px; }
        .message.error { background: #fee; color: #c00; }
        .typing-indicator { display: none; align-self: flex-start; padding: 12px 16px; background: #f0f0f0; border-radius: 16px; border-bottom-left-radius: 4px; }
        .typing-indicator.visible { display: flex; gap: 4px; }
        .typing-indicator span { width: 8px; height: 8px; background: #999; border-radius: 50%; animation: bounce 1.4s infinite ease-in-out; }
        .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
        .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
        @keyframes bounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
        .chat-input-container { padding: 20px; border-top: 1px solid #eee; display: flex; gap: 10px; }
        .chat-input { flex: 1; padding: 12px 16px; border: 2px solid #eee; border-radius: 24px; font-size: 1rem; outline: none; transition: border-color 0.2s; }
        .chat-input:focus { border-color: #667eea; }
        .send-button { padding: 12px 24px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 24px; font-size: 1rem; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; }
        .send-button:hover { transform: scale(1.05); box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4); }
        .send-button:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .welcome-message { text-align: center; padding: 40px 20px; color: #666; }
        .welcome-message h2 { margin-bottom: 10px; color: #333; }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            <h1>Odoo AI Assistant</h1>
            <p>Ask me anything about your Odoo data</p>
        </div>
        <div class="chat-messages" id="chatMessages">
            <div class="welcome-message">
                <h2>Welcome!</h2>
                <p>Start a conversation by typing a message below.<br>I can help you query and manage your Odoo data.</p>
            </div>
        </div>
        <div class="typing-indicator" id="typingIndicator">
            <span></span><span></span><span></span>
        </div>
        <div class="chat-input-container">
            <input type="text" class="chat-input" id="chatInput" placeholder="Type your message..." autocomplete="off">
            <button class="send-button" id="sendButton">Send</button>
        </div>
    </div>
    <script>
        const chatMessages = document.getElementById('chatMessages');
        const chatInput = document.getElementById('chatInput');
        const sendButton = document.getElementById('sendButton');
        const typingIndicator = document.getElementById('typingIndicator');
        let sessionId = 'web-' + Math.random().toString(36).substring(2, 15);
        let isFirstMessage = true;
        function addMessage(content, role) {
            if (isFirstMessage) {
                const welcomeMessage = chatMessages.querySelector('.welcome-message');
                if (welcomeMessage) welcomeMessage.remove();
                isFirstMessage = false;
            }
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + role;
            messageDiv.textContent = content;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        function showTyping() { typingIndicator.classList.add('visible'); chatMessages.scrollTop = chatMessages.scrollHeight; }
        function hideTyping() { typingIndicator.classList.remove('visible'); }
        async function sendMessage() {
            const message = chatInput.value.trim();
            if (!message) return;
            addMessage(message, 'user');
            chatInput.value = '';
            sendButton.disabled = true;
            showTyping();
            try {
                const response = await fetch('/api/agents/odooAgent/generate-legacy', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ messages: [{ role: 'user', content: message }], resourceId: sessionId, threadId: sessionId })
                });
                if (!response.ok) throw new Error('HTTP error! status: ' + response.status);
                const data = await response.json();
                hideTyping();
                if (data.text) addMessage(data.text, 'assistant');
                else if (data.error) addMessage('Error: ' + data.error, 'error');
                else addMessage('Received response but no text content.', 'assistant');
            } catch (error) {
                hideTyping();
                addMessage('Failed to get response. Please try again.', 'error');
                console.error('Error:', error);
            }
            sendButton.disabled = false;
            chatInput.focus();
        }
        sendButton.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
        chatInput.focus();
    </script>
</body>
</html>`;
            return c.html(html);
          };
        }
      },
      // ======================================================================
      // Inngest Integration Endpoint
      // ======================================================================
      // Integrates Mastra workflows with Inngest for event-driven execution via inngest functions.
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
      },
      // Telegram webhook trigger for Odoo voice commands
      ...registerTelegramTrigger({
        triggerType: "telegram/message",
        handler: async (mastra2, triggerInfo) => {
          const logger = mastra2.getLogger();
          logger?.info("\u{1F4F1} [Telegram Trigger] Received message:", {
            userName: triggerInfo.params.userName,
            chatId: triggerInfo.params.chatId,
            hasVoice: !!triggerInfo.params.voiceFileId,
            hasText: !!triggerInfo.params.message
          });
          const threadId = `telegram-${triggerInfo.params.chatId}`;
          let userMessage = triggerInfo.params.message || "";
          if (triggerInfo.params.voiceFileId) {
            userMessage = `[Voice message received with file_id: ${triggerInfo.params.voiceFileId}]

Please:
1. First download this voice file using the downloadTelegramFileTool with file_id: ${triggerInfo.params.voiceFileId}
2. Then transcribe it using transcribeVoiceTool
3. Process the transcribed command and execute the requested Odoo operation
4. Return the result of the operation`;
          }
          if (!userMessage) {
            userMessage = "Hello! I didn't receive any text or voice message. Please send a message or voice note with your request.";
          }
          const run = await odooTelegramWorkflow.createRunAsync();
          await inngest.send({
            name: `workflow.${odooTelegramWorkflow.id}`,
            data: {
              runId: run?.runId,
              inputData: {
                chatId: triggerInfo.params.chatId,
                userMessage,
                threadId
              }
            }
          });
          logger?.info("\u2705 [Telegram Trigger] Workflow started:", {
            runId: run?.runId
          });
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
